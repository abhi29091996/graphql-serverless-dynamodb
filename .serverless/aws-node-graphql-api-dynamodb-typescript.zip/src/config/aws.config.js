"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const aws_sdk_1 = __importDefault(require("aws-sdk"));
const env_1 = require("./env");
aws_sdk_1.default.config.update({
    region: env_1.region,
    accessKeyId: env_1.accessKey,
    secretAccessKey: env_1.secretKey,
});
exports.default = aws_sdk_1.default;
