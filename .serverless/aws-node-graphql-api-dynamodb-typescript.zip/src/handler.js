"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.graphqlHandler = void 0;
const apollo_server_lambda_1 = require("apollo-server-lambda");
// import { makeExecutableSchema } from "graphql-tools";
const Resolvers_1 = require("./Resolvers");
const Schema_1 = require("./Schema");
// const schema = makeExecutableSchema({
//   typeDefs,
//   resolvers,
// });
const server = new apollo_server_lambda_1.ApolloServer({
    typeDefs: Schema_1.typeDefs,
    resolvers: Resolvers_1.resolvers
});
// exports.graphql = (event: any, context: any, callback: any) => {
//   const callbackFilter = (error: any, output: any) => {
//     const outputWithHeader = Object.assign({}, output, {
//       headers: {
//         "Access-Control-Allow-Origin": "*",
//       },
//     });
//     callback(error, outputWithHeader);
//   };
//   graphqlLambda({ schema })(event, context, callbackFilter);
// };
exports.graphqlHandler = server.createHandler();
